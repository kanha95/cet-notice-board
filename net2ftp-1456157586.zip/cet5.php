<?php
	include 'db.php';
	$t=$_GET["pp"];
	$q=mysqli_query($p,"select slno,Date,Posted_by,Subject,Message,Attachment from notic where slno='$t'");
	
	 $arr=mysqli_fetch_array($q);
	 	
		
		$t=explode(',',$arr["Attachment"]);
		print '<!Doctype HTML>
<html>
<head>
<title>
Notice
</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="robots" content="noindex,follow">
        <meta name="Description" content="Notice">
<link rel="stylesheet" type="text/css" href="../bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="../bootstrap.css">
<link rel="stylesheet" type="text/css" href="../test2.css">
<link rel="shortcut icon" type="image/x-icon" href="../login-logo.jpg" />
</head>
<body>
<div class="container">






    <p>Posted By: '.$arr["Posted_by"].'</p>
    <p>Date Time:'.$arr["Date"].'</p>

    <p> Subject: '.$arr["Subject"].'</p>

    <p> Message:</br> '.$arr["Message"].'</p>

   
</body>
</html>';
		echo "Attachments:-"."<br>";
		foreach($t as $k)
		{
		echo '<a href="'.$k.'" target="_blank">'.$k.'</a>'."<br>";	
		}
//

//
		
		
	 


?>
  
