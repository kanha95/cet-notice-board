<?php

		$p=mysqli_connect("mysql.hostinger.in","u684872378_cetb","123456","u684872378_cet");
		if(!$p)
	    {
		die("not connected "."<br>".mysql_error());		
	    }	
		
		
		
?>