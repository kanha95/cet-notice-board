<?php
	$u=$_POST["slno"];
	include 'db.php';
         
	if(isset($_POST["del"]))
	{
		mysqli_query($p,"delete from notic where slno='".$u."'");
	    header ("location:cet4.php");
	}

	$w=mysqli_query($p,"select * from notic where slno='".$u."'");
	if($arr=mysqli_fetch_array($w))
	{
		echo '
			<form method="post">
			Your Name:<br><input type="text" name="name" value="'.$arr["Posted_by"].'" /><br>
			Subject:<br><input type="text" name="sub" value="'.$arr["Subject"].'" /><br>
            Message:<br><input type="text" name="message" value="'.$arr["Message"].'" /><br>
            Attachment:<br><input type="file" name="file" multiple="" value="'.$arr["Attachment"].'"/><br><br>
            <input type="submit" value="Update" name="submit" />
			<input type="submit" value="Cancel" name="cancel" />
			</form>
			';
	}
	if(isset($_POST["submit"]))
	{
		$name=$_REQUEST["name"];
		$sub=$_REQUEST["sub"];
		$mes=$_REQUEST["message"];
		$file=$_REQUEST["file"];
		$w=mysqli_query($p,"update notic set Date=current_timestamp, Posted_by='".$name."',Subject='".$sub."',Message='".$mes."',Attachment='".$file."'        where slno='".$u."'");
		if($w)
		{
		header ("location:cet4.php");	
		}
			
	}
	if(isset($_REQUEST["cancel"]))
	{
	header ("location:cet4.php");	
	}
?>


