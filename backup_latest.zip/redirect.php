<?php
if(isset($_REQUEST["ad"]) AND $_SERVER['REQUEST_METHOD']=="POST"){
header("Location: http://notices.cetb.in/admin.php");
}
else if(isset($_REQUEST["us"]) AND $_SERVER['REQUEST_METHOD']=="POST"){
header("Location: http://notices.cetb.in/n_user.php");
}
else{
header("Location: http://notices.cetb.in/index.php");
}
?>