<?php
	$u=$_REQUEST["slno"];
	include 'db.php';
         
	if(isset($_REQUEST["appr"]) AND $_SERVER['REQUEST_METHOD']=='POST')
	{
		$q=mysqli_query($p,"select slno,Date_2,Posted_by,Subject_2,Message,Attachment from n_user where slno='".$u."' ");
                $arr=mysqli_fetch_array($q);
//gcm messaging

function sendMessageThroughGCM($registatoin_ids, $message) {
		//Google cloud messaging GCM-API url
        $url = 'https://android.googleapis.com/gcm/send';


        $fields = array(
            'registration_ids' => $registatoin_ids,
            'data' => $message,
        );
		// Update your Google Cloud Messaging API Key
		define("GOOGLE_API_KEY", "AIzaSyCjfi5aCLbJOlYW9Yu0FXWckbbs_z_Wz6g"); 		
        $headers = array(
            'Authorization: key=' . GOOGLE_API_KEY,
            'Content-Type: application/json'
        );
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt ($ch, CURLOPT_SSL_VERIFYHOST, 0);	
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
        $result = curl_exec($ch);				
        if ($result === FALSE) {
            die('Curl failed: ' . curl_error($ch));
        }
        curl_close($ch);
        return $result;
    }

                $q=mysqli_query($p,"select userid from gcmusers");
		while($gcmRegID=mysqli_fetch_array($q)){
                $gcmregid=array();
                $gcmregid[0]=$gcmRegID[0];
   
		$pushMessage ="a";	
		if (isset($gcmRegID) && isset($pushMessage)) {		
		
			$message = array("m" => $pushMessage);	
			$pushStatus = sendMessageThroughGCM($gcmregid, $message);
		}		
	
}




//
              	
if(mysqli_query($p,"insert into notic values(0,current_date,'".$arr["Posted_by"]."','".$arr["Subject_2"]."','".$arr["Message"]."','".$arr['Attachment']."')")){
//

print'<!Doctype HTML>
<html>
<head>
<title>
Notice
</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="robots" content="noindex,follow">
        <meta name="Description" content="Notice">
<link rel="stylesheet" type="text/css" href="../bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="../bootstrap.css">
<link rel="stylesheet" type="text/css" href="../test2.css">
<link rel="shortcut icon" type="image/x-icon" href="../login-logo.jpg" />
</head>
<body>
<div class="container">
';
     print"<strong>Thanks For Approving !!!</strong>";
      
      print '<p><a href="index.php">View Notice Board</a></p>';

//
} 
        mysqli_query($p,"delete from n_user where slno='".$u."'");

	}
if(isset($_REQUEST["disc"]) AND $_SERVER['REQUEST_METHOD']=='POST'){

 if(mysqli_query($p,"delete from n_user where slno='".$u."'")){
header("Location:admin.php");
}
}
	
?>