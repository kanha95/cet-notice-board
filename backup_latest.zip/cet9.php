<?php
	include 'db.php';
	$t=$_GET["pp"];
	$q=mysqli_query($p,"select slno,Date_2,Posted_by,Subject_2,Message,Attachment from n_user where slno='$t'");
	
	 $arr=mysqli_fetch_array($q);
	 	
		
		$t=explode(',',$arr["Attachment"]);
		print '<!Doctype HTML>
<html>
<head>
<title>
Notice
</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="robots" content="noindex,follow">
        <meta name="Description" content="Notice">
<link rel="stylesheet" type="text/css" href="../bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="../bootstrap.css">
<link rel="stylesheet" type="text/css" href="../test2.css">
<link rel="shortcut icon" type="image/x-icon" href="../login-logo.jpg" />
</head>
<body>
<div class="container">';



$reg_exUrl = "/(http|https|ftp|ftps)\:\/\/[a-zA-Z0-9\-\.]+\.[a-zA-Z]{2,3}(\/\S*)?/";


$text=$arr["Message"];
print '
    <p>Posted By: '.$arr["Posted_by"].'</p>
    <p>Date Time:'.$arr["Date_2"].'</p>

    <p> Subject: '.$arr["Subject_2"].'</p>';
if(preg_match_all($reg_exUrl, $text, $url)) {

       // make the urls hyper links
echo "<p>Message:</p><p>";
$a=$url[0];

       echo preg_replace($reg_exUrl, " (link given below)", $text);

print '<br/>';

echo "</p>";
foreach($a as $k => $v){
$mk=$k+1;
print "<p>Link ".$mk." : <a href='".$v."'>".$v."</a></p>";
}
   
}else{
echo "<p>Message:</p><p>".$text."</p>";
}
 

   print'

   
</body>
</html>';
		echo "<p>Attachments:-</p>";
		foreach($t as $k)
		{
		echo '<a href="uploads/'.$k.'" target="_blank">'.$k.'</a>'."<br/>";	
		}
//

//
		
		
	 


?>
  
