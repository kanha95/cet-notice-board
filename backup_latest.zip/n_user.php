<?php


if($_SERVER['REQUEST_METHOD']!='POST'){
print '
<!Doctype HTML>
<html>
<head>
<title>
Notice
</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="robots" content="noindex,follow">
        <meta name="Description" content="Notice">
<link rel="stylesheet" type="text/css" href="../bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="../bootstrap.css">
<link rel="stylesheet" type="text/css" href="../test2.css">
<link rel="shortcut icon" type="image/x-icon" href="../login-logo.jpg" />
</head>
<body>

<div class="container">
<div class="row-center" >
  <div class="col-md-6 col-xs-6 col-md-offset-4">
  <form  id="input" enctype="multipart/form-data" method="post">
  <br><p>Your Name:</p>
   <input type="text"  name="name" size="28" maxlength="15" placeholder="max 15 characters" />


 <p>Subject:</p>
  <textarea wrap="soft"   name="sub" rows="2" cols="30" maxlength="20"  placeholder="max 20 characters"></textarea>

  </br><p>Message:</p>
  <textarea wrap="soft"  name="message"  rows="9" cols="30" maxlength="1000"  placeholder="max 500 characters"></textarea>

  <p>Attachments:</p>

  <input type="file" name="f" />
<input type="file" name="ft" />
 <input type="hidden" name="MAX_FILE_SIZE" value="30000" />
 </br>

  <input type="submit" name="submit" class="btn btn-primary" value="&nbsp;&nbsp;Post&nbsp;&nbsp;"/>

  </form>

</div>
</div>

</div>

</body>
</html>';
}

 if(isset($_REQUEST["submit"]) AND $_SERVER['REQUEST_METHOD']=="POST")
	{
	
               
             
              if($_FILES["f"]["size"]>0){
		$fname=$_FILES["f"]["name"];
                
	    $file=$_FILES["f"]["tmp_name"];
            $fname=strrev($fname);//extracting the format of file uploaded
            $fname=strtok($fname,'.');
            $fname=strrev($fname);
            $hk=uniqid();
            $fname=$hk.'.'.$fname;
	    move_uploaded_file($file,"uploads/$fname");
               
}
 if($_FILES["ft"]["size"]>0){
		$fname1=$_FILES["ft"]["name"];
	    $file1=$_FILES["ft"]["tmp_name"];
             $fname1=strrev($fname1);//extracting the format of file uploaded
            $fname1=strtok($fname1,'.');
            $fname1=strrev($fname1);
            $hk1=uniqid();
            $fname1=$hk1.'.'.$fname1;
                
	    move_uploaded_file($file1,"uploads/$fname1");
               
}
		$p=mysqli_connect("mysql.hostinger.in","u684872378_cetb","123456","u684872378_cet");
		if(!$p)
	    {
		die("not connected "."<br>".mysql_error());		
	    }	
		
		 $name=mysqli_real_escape_string($p,$_REQUEST["name"]);
                $sub=mysqli_real_escape_string($p,$_REQUEST["sub"]);
                $msg=mysqli_real_escape_string($p,$_REQUEST["message"]);
		
//

$ip = "";

if (!empty($_SERVER["HTTP_CLIENT_IP"]))
{
 //check for ip from share internet
 $ip = $_SERVER["HTTP_CLIENT_IP"];
}
elseif (!empty($_SERVER["HTTP_X_FORWARDED_FOR"]))
{
 // Check for the Proxy User
 $ip = $_SERVER["HTTP_X_FORWARDED_FOR"];
}
else
{
 $ip = $_SERVER["REMOTE_ADDR"];
}

date_default_timezone_set('Asia/Kolkata');

//
//



//


		mysqli_query($p,"insert into Temp values(0,current_timestamp,'".$name."','".$sub."','".$msg."','".$fname.','.$fname1."','".$ip."')");
		if(mysqli_query($p,"insert into n_user values(0,current_timestamp,'".$name."','".$sub."','".$msg."','".$fname.','.$fname1."','".$ip."')")){
//

print'<!Doctype HTML>
<html>
<head>
<title>
Notice
</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="robots" content="noindex,follow">
        <meta name="Description" content="Notice">
<link rel="stylesheet" type="text/css" href="../bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="../bootstrap.css">
<link rel="stylesheet" type="text/css" href="../test2.css">
<link rel="shortcut icon" type="image/x-icon" href="../login-logo.jpg" />
</head>
<body>
<div class="container">
';
     
     print"<strong>Thanks For submitting !!!</br>Please Wait For An Admin To Approve Your Post.</strong>";
      print '<p><a href="n_user.php">Post Another Notice</a></p>';
      print '<p><a href="index.php">View Notice Board</a></p>';
     echo '<strong><em>Your Public Ip Has Been Traced: '.$ip.'</em></strong>';

//
}
			
	}


?>