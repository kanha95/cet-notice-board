<!Doctype HTML>
<html>
<head>
<title>
Notice
</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="robots" content="noindex,follow">
        <meta name="Description" content="Notice">
<link rel="stylesheet" type="text/css" href="../bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="../bootstrap.css">
<link rel="stylesheet" type="text/css" href="../test2.css">
<link rel="shortcut icon" type="image/x-icon" href="../login-logo.jpg" />
</head>
<body>
<div class="container">


           <div class="headline">
          <div align="center"><strong><font color="#272621">CET NOTICE BOARD<font></strong></div>
        </div></div>
        <div class="Notice">
          <table width="100%" border="1" cellpadding="5" cellspacing="2" bgcolor="#ffffff">
					
            <tr>
              <td bgcolor="#2B4B62"><strong><font color="white">Date</font></strong></td>
              <td bgcolor="#2B4B62"><strong><font color="white">Subject</font></strong></td>
							<td bgcolor="#2B4B62"><strong><font color="white">Posted By</font></strong></td>

            </tr>
<?php
if($_SERVER['REQUEST_METHOD']!='POST'){
	include 'db.php';
	$q=mysqli_query($p,"select slno,Date_1,Posted_by,Subject_1 from notic order by slno desc limit 20");
	


	     while($arr=mysqli_fetch_array($q))
		 {
               
			 echo '<form action="index.php">';

   echo '	<tr>
			  <td bgcolor="#f1f1f1"><strong>'.$arr["Date_1"].'
       </strong></td>
			  <td  bgcolor="#f1f1f1" ><a href="cet5.php?pp='.$arr["slno"].'">'.$arr["Subject_1"].'</a></td>
					  <td bgcolor="#f1f1f1"><strong><font color="red">'.$arr["Posted_by"].'</font></strong></td>

<input type="hidden" name="slno" value="'.$arr["slno"].'" />

		    </tr> ';
      
			echo '</form>';
		 }
	echo '</table>';
}
?>
  
        <table width="100%" border="0" cellpadding="5" cellspacing="2" bgcolor="#ffffff">
<tr><form action="cet10.php" method="post">
<td>
<?php
$i=15;
print '<input type="submit" name="pn" value="POST A NOTICE" class="btn btn-primary" /></form>';
while($i>0){
print '&nbsp;&nbsp;&nbsp;&nbsp;';
$i--;
}
?>
</td>

<td>
<form action="cet6.php" method="post">
<input type="submit" name="next" value="older>>>" class="btn btn-primary" /></td></tr>
<tr>

<?php
include 'db.php';
$ip = "";

if (!empty($_SERVER["HTTP_CLIENT_IP"]))
{
 //check for ip from share internet
 $ip = $_SERVER["HTTP_CLIENT_IP"];
}
elseif (!empty($_SERVER["HTTP_X_FORWARDED_FOR"]))
{
 // Check for the Proxy User
 $ip = $_SERVER["HTTP_X_FORWARDED_FOR"];
}
else
{
 $ip = $_SERVER["REMOTE_ADDR"];
}
echo '<strong><em>Your Public Ip Is: '.$ip.'</em></strong>';
date_default_timezone_set('Asia/Kolkata');
mysqli_query($p,"insert into visitors values(0,current_date,current_time,'".$ip."')");
//
//

?>
</tr>
</form>
</table>

</body></html>
