<?php
 if(isset($_REQUEST["pn"]) AND $_SERVER['REQUEST_METHOD']=="POST")	{
print '
<!Doctype HTML>
<html>
<head>
<title>
Notice
</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="robots" content="noindex,follow">
        <meta name="Description" content="Notice">
<link rel="stylesheet" type="text/css" href="../bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="../bootstrap.css">
<link rel="stylesheet" type="text/css" href="../test2.css">
<link rel="shortcut icon" type="image/x-icon" href="../login-logo.jpg" />
</head>
<body>

<div class="container">
<div class="row-center" >
  <div class="col-md-6 col-xs-6 col-md-offset-4">
  <form  id="input" method="post" action="redirect.php">
  <p>Select Your Choice:</p>
<p><input type="submit" name="ad" value="Post As Admin" class="btn btn-primary" /></p>
<p><input type="submit" name="us" value="Post As User" class="btn btn-primary" /></p>

  </form>

</div>
</div>

</div>

</body>
</html>';
}
else {
print '

<!Doctype HTML>
<html>
<head>
<title>
Notice
</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="robots" content="noindex,follow">
        <meta name="Description" content="Notice">
<link rel="stylesheet" type="text/css" href="../bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="../bootstrap.css">
<link rel="stylesheet" type="text/css" href="../test2.css">
<link rel="shortcut icon" type="image/x-icon" href="../login-logo.jpg" />
</head>
<body>
<div class="container">


           <div class="headline">
          <div align="center"><strong><font color="#272621">CET NOTICE BOARD<font></strong></div>
        </div></div>
        <div class="Notice">
          <table width="100%" border="1" cellpadding="5" cellspacing="2" bgcolor="#ffffff">
					
            <tr>
              <td bgcolor="#2B4B62"><strong><font color="white">Date</font></strong></td>
              <td bgcolor="#2B4B62"><strong><font color="white">Subject</font></strong></td>
							<td bgcolor="#2B4B62"><strong><font color="white">Posted By</font></strong></td>

            </tr>';
}
	$u=$_REQUEST["slno"];
	include 'db.php';
         
	if(isset($_REQUEST["del"]) AND $_SERVER['REQUEST_METHOD']=='POST')
	{
              
		mysqli_query($p,"delete from notic where slno='".$u."'");
      
	    header ("location:index.php");
	}
   
        if(isset($_REQUEST["next"]) AND $_SERVER['REQUEST_METHOD']=="POST")	{

	$q=mysqli_query($p,"select slno,Date_1,Posted_by,Subject_1 from notic order by slno desc limit 20 offset 20");
	


	     while($arr=mysqli_fetch_array($q))
		 {
			 echo '<form action="index.php">';

   echo '	<tr>
			  <td bgcolor="#f1f1f1"><strong>'.$arr["Date_1"].'
       </strong></td>
			  <td  bgcolor="#f1f1f1" ><a href="cet5.php?pp='.$arr["slno"].'">'.$arr["Subject_1"].'</a></td>
					  <td bgcolor="#f1f1f1"><strong><font color="red">'.$arr["Posted_by"].'</font></strong></td>

<input type="hidden" name="slno" value="'.$arr["slno"].'" />

		    </tr> ';
      
			echo '</form>';
		 }
	echo '</table>';



print '    <table width="100%" border="0" cellpadding="5" cellspacing="2" bgcolor="#ffffff">
<tr><form action="cet6.php" method="post">
<td>
';
$i=15;
while($i>0){
print '&nbsp;&nbsp;&nbsp;&nbsp;';
$i--;
}

print '</td>

<td><input type="submit" name="prev" value="<<<newer" class="btn btn-primary"/><input type="submit" name="next2" value="older>>>" class="btn btn-primary"/></td></tr>
</form>';
}
//
 if(isset($_REQUEST["next2"]) AND $_SERVER['REQUEST_METHOD']=="POST")	{

	$q=mysqli_query($p,"select slno,Date_1,Posted_by,Subject_1 from notic order by slno desc limit 20 offset 40");
	


	     while($arr=mysqli_fetch_array($q))
		 {
			 echo '<form action="index.php">';

   echo '	<tr>
			  <td bgcolor="#f1f1f1"><strong>'.$arr["Date_1"].'
       </strong></td>
			  <td  bgcolor="#f1f1f1" ><a href="cet5.php?pp='.$arr["slno"].'">'.$arr["Subject_1"].'</a></td>
					  <td bgcolor="#f1f1f1"><strong><font color="red">'.$arr["Posted_by"].'</font></strong></td>

<input type="hidden" name="slno" value="'.$arr["slno"].'" />

		    </tr> ';
      
			echo '</form>';
		 }
	echo '</table>';


print '    <table width="100%" border="0" cellpadding="5" cellspacing="2" bgcolor="#ffffff">
<tr><form action="cet6.php" method="post">
<td>
';
$i=15;
while($i>0){
print '&nbsp;&nbsp;&nbsp;&nbsp;';
$i--;
}

print '</td>

<td><input type="submit" name="next" value="<<<newer" class="btn btn-primary"/></td></tr>
</form>';
}

//
	if(isset($_REQUEST["prev"]) AND $_SERVER['REQUEST_METHOD']=='POST'){
header("Location:index.php");
}
	
?>

</body>
</html>