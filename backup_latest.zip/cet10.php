<?php

if(isset($_REQUEST["pn"]) AND $_SERVER['REQUEST_METHOD']=="POST")	{
print '
<!Doctype HTML>
<html>
<head>
<title>
Notice
</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="robots" content="noindex,follow">
        <meta name="Description" content="Notice">
<link rel="stylesheet" type="text/css" href="../bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="../bootstrap.css">
<link rel="stylesheet" type="text/css" href="../test2.css">
<link rel="shortcut icon" type="image/x-icon" href="../login-logo.jpg" />
</head>
<body>

<div class="container">
<div class="row-center" >
  <div class="col-md-6 col-xs-6 col-md-offset-4">
  <form  id="input" method="post" action="redirect.php">
  <p>Select Your Choice:</p>
<p><input type="submit" name="ad" value="Post As Admin" class="btn btn-primary" /></p>
<p><input type="submit" name="us" value="Post As User" class="btn btn-primary" /></p>

  </form>

</div>
</div>

</div>

</body>
</html>';
}


?>