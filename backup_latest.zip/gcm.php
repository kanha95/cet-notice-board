<?php
	
	//Get Reg ID sent from Android App and store it in text file
	if(!empty($_GET["shareRegId"])) {
		$gcmRegID  = $_POST["regId"]; 
                
                $p=mysqli_connect("mysql.hostinger.in","u684872378_cetb","123456","u684872378_cet");
            if(!$p)
	    {
		die("not connected "."<br>".mysql_error());		
	    }	
            if(mysqli_query($p,"insert into gcmusers values(0,'".$gcmRegID."')")){
	
		echo "Done!";
		exit;

	}
}
echo "Unknown Authorisation !!!";
?>
