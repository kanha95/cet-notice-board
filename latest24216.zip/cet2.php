<?php
    session_start();
//
	
if($_SERVER['REQUEST_METHOD']!="POST"){


print '

<!Doctype HTML>
<html>
<head>
<title>
Login
</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="robots" content="noindex,follow">
        <meta name="Description" content="Login">
<link rel="stylesheet" type="text/css" href="../bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="../bootstrap.css">
<link rel="stylesheet" type="text/css" href="../login.css">
<link rel="shortcut icon" type="image/x-icon" href="../login-logo.jpg" />
</head>
<body>

<div class="container">
	<div class="row">
    <div class="col-sm-4"></div>


<div class="col-sm-4">

  <div id="login">
<form name="loginform" id="loginform"  method="post">
	<p>
		<label for="user_login"><span style="color:#fff">Username</span><br />
		<input type="text" name="uid" id="user_login" class="input" value="" size="20" style="width:290px;" /></label>
	</p>
	<p>
		<label for="user_pass"><span style="color:#fff">Password</span><br />
		<input type="password" name="pwd" id="user_pass" class="input" value="" size="20" style="width:290px";/></label>
	</p>
		<p class="forgetmenot"><label for="rememberme"><input name="rememberme" type="checkbox" id="rememberme" value="forever" style="margin-top:20px;"  /> <span style="color:#fff">Remember Me</span></label></p>
	<p class="submit">
		<input type="submit" name="login" id="wp-submit" class="btn btn-primary"   value="Login"  />

	</p>
</form></div></div>

<div class="col-sm-4"></div>


</div>
</div>
</body>
</html>';
}


//
	if(isset($_REQUEST["login"]) AND $_SERVER['REQUEST_METHOD']=="POST")
	{
	    include 'db.php';
				
		$uid=mysqli_real_escape_string($p,$_REQUEST["uid"]);
		$pwd=mysqli_real_escape_string($p,$_REQUEST["pwd"]);
        $q=mysqli_query($p,"select * from login where userid='".$uid."' and password='".$pwd."'");
		if($arr=mysqli_fetch_array($q))
		 {
			$_SESSION["uid"]=$uid;
		//

print '
<!Doctype HTML>
<html>
<head>
<title>
Notice
</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="robots" content="noindex,follow">
        <meta name="Description" content="Notice">
<link rel="stylesheet" type="text/css" href="../bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="../bootstrap.css">
<link rel="stylesheet" type="text/css" href="../test2.css">
<link rel="shortcut icon" type="image/x-icon" href="../login-logo.jpg" />
</head>
<body>

<div class="container">
<div class="row-center" >
  <div class="col-md-6 col-xs-6 col-md-offset-4">
  <form  id="input" method="post">
  <p>Select Your Action:</p>
<p><input type="submit" name="nu" value="Approve Notice" class="btn btn-primary" /></p>
<p><input type="submit" name="ed" value="Delete a Notice" class="btn btn-primary" /></p>
<p><input type="submit" name="pt" value="Post a Notice" class="btn btn-primary" /></p>
<p><input type="submit" name="vw" value="View Notice Board" class="btn btn-primary" /></p>

  </form>

</div>
</div>

</div>

</body>
</html>';



	



//
		 }
		 else
		 {
		//

print'<!Doctype HTML>
<html>
<head>
<title>
Notice
</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="robots" content="noindex,follow">
        <meta name="Description" content="Notice">
<link rel="stylesheet" type="text/css" href="../bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="../bootstrap.css">
<link rel="stylesheet" type="text/css" href="../test2.css">
<link rel="shortcut icon" type="image/x-icon" href="../login-logo.jpg" />
</head>
<body>
<div class="container">
';
     print"<strong><font color=\"red\">Sorry!!!You Dont Have Access At This Point Of Time.</font></strong>";
      

//	   
	     }
	}
	
	
	
    if(isset($_REQUEST["submit"]) AND $_SERVER['REQUEST_METHOD']=="POST")
	{
		$fname=$_FILES["f"]["name"];
	    $file=$_FILES["f"]["tmp_name"];
	    move_uploaded_file($file,$fname);
		$fname1=$_FILES["ft"]["name"];
	    $file1=$_FILES["ft"]["tmp_name"];
	    move_uploaded_file($file1,$fname1);
		$p=mysqli_connect("mysql.hostinger.in","u684872378_cetb","123456","u684872378_cet");
		if(!$p)
	    {
		die("not connected "."<br>".mysql_error());		
	    }	
		
		
		
		
		if(mysqli_query($p,"insert into notic values(0,current_date,'".$_REQUEST["name"]."','".$_REQUEST["sub"].        "','".$_REQUEST[        "message"]."','".$fname.','.$fname1."')")){
//

print'<!Doctype HTML>
<html>
<head>
<title>
Notice
</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="robots" content="noindex,follow">
        <meta name="Description" content="Notice">
<link rel="stylesheet" type="text/css" href="../bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="../bootstrap.css">
<link rel="stylesheet" type="text/css" href="../test2.css">
<link rel="shortcut icon" type="image/x-icon" href="../login-logo.jpg" />
</head>
<body>
<div class="container">
';
     print"<strong>Thanks For submitting !!!</strong>";
      print '<p><a href="cet2.php">Post Another Notice</a></p>';
      print '<p><a href="cet7.php">View Notice Board</a></p>';

//
}
			
	}
//
 if(isset($_REQUEST["ed"]) AND $_SERVER['REQUEST_METHOD']=="POST"){
print '<!Doctype HTML>
<html>
<head>
<title>
Notice
</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="robots" content="noindex,follow">
        <meta name="Description" content="Notice">
<link rel="stylesheet" type="text/css" href="../bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="../bootstrap.css">
<link rel="stylesheet" type="text/css" href="../test2.css">
<link rel="shortcut icon" type="image/x-icon" href="../login-logo.jpg" />
</head>
<body>
<div class="container">


           <div class="headline">
          <div align="center"><strong><font color="#272621">CET NOTICE BOARD<font></strong></div>
        </div></div>
        <div class="Notice">
          <table width="100%" border="1" cellpadding="5" cellspacing="2" bgcolor="#ffffff">
					
            <tr>
              <td bgcolor="#2B4B62"><strong><font color="white">Date</font></strong></td>
              <td bgcolor="#2B4B62"><strong><font color="white">Subject</font></strong></td>
							<td bgcolor="#2B4B62"><strong><font color="white">Posted By</font></strong></td>
<td bgcolor="#2B4B62"><strong><font color="white">Action</font></strong></td>
            </tr>
';
	include 'db.php';
	$q=mysqli_query($p,"select slno,Date_1,Posted_by,Subject_1 from notic order by slno desc");
	


	     while($arr=mysqli_fetch_array($q))
		 {
			 echo '<form action="cet6.php" method="post">';

   echo '	<tr>
			  <td bgcolor="#f1f1f1"><strong>'.$arr["Date_1"].'
       </strong></td>
			  <td  bgcolor="#f1f1f1" ><a href="cet5.php?pp='.$arr["slno"].'">'.$arr["Subject_1"].'</a></td>
					  <td bgcolor="#f1f1f1"><strong><font color="red">'.$arr["Posted_by"].'</font></strong></td>
<td bgcolor="#f1f1f1">
<input type="hidden" name="slno" value="'.$arr["slno"].'" />
			     <input type="submit" name="del" value="Delete" onclick="return confirm(\'Are you sure,you want to delete this post?\')"/></td>
		    </tr> ';
      
			echo '</form>';
		 }

  print ' </table></body></html>';
	


}
//
if(isset($_REQUEST["pt"]) AND $_SERVER['REQUEST_METHOD']=="POST"){

print '
<!Doctype HTML>
<html>
<head>
<title>
Notice
</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="robots" content="noindex,follow">
        <meta name="Description" content="Notice">
<link rel="stylesheet" type="text/css" href="../bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="../bootstrap.css">
<link rel="stylesheet" type="text/css" href="../test2.css">
<link rel="shortcut icon" type="image/x-icon" href="../login-logo.jpg" />
</head>
<body>

<div class="container">
<div class="row-center" >
  <div class="col-md-6 col-xs-6 col-md-offset-4">
  <form  id="input" enctype="multipart/form-data" method="post">
  <br><p>Your Name:</p>
   <input type="text"  name="name" size="28" maxlength="15" />


 <p>Subject:</p>
  <textarea wrap="soft"   name="sub" rows="2" cols="30" maxlength="20"></textarea>

  </br><p>Message:</p>
  <textarea wrap="soft"  name="message"  rows="9" cols="30" maxlength="1000"></textarea>

  <p>Attachments:</p>
 <input type="hidden" name="MAX_FILE_SIZE" value="30000" />
  <input type="file" name="f" />
<input type="file" name="ft" />
 </br>

  <input type="submit" name="submit" class="btn btn-primary" value="&nbsp;&nbsp;Post&nbsp;&nbsp;"/>

  </form>

</div>
</div>

</div>

</body>
</html>';
}		
if(isset($_REQUEST["vw"]) AND $_SERVER['REQUEST_METHOD']=="POST"){
header("Location:cet7.php");
}	
//
if(isset($_REQUEST["nu"]) AND $_SERVER['REQUEST_METHOD']=="POST"){
print '<!Doctype HTML>
<html>
<head>
<title>
Notice
</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="robots" content="noindex,follow">
        <meta name="Description" content="Notice">
<link rel="stylesheet" type="text/css" href="../bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="../bootstrap.css">
<link rel="stylesheet" type="text/css" href="../test2.css">
<link rel="shortcut icon" type="image/x-icon" href="../login-logo.jpg" />
</head>
<body>
<div class="container">


           <div class="headline">
          <div align="center"><strong><font color="#272621">CET NOTICE BOARD<font></strong></div>
        </div></div>
        <div class="Notice">
          <table width="100%" border="1" cellpadding="5" cellspacing="2" bgcolor="#ffffff">
					
            <tr>
              <td bgcolor="#2B4B62"><strong><font color="white">Date</font></strong></td>
              <td bgcolor="#2B4B62"><strong><font color="white">Subject</font></strong></td>
							<td bgcolor="#2B4B62"><strong><font color="white">Posted By</font></strong></td>
<td bgcolor="#2B4B62"><strong><font color="white">Action</font></strong></td>
            </tr>
';
	include 'db.php';
	$q=mysqli_query($p,"select slno,Date_2,Posted_by,Subject_2 from n_user order by slno desc");
	


	     while($arr=mysqli_fetch_array($q))
		 {
			 echo '<form action="cet8.php" method="post">';

   echo '	<tr>
			  <td bgcolor="#f1f1f1"><strong>'.$arr["Date_2"].'
       </strong></td>
			  <td  bgcolor="#f1f1f1" ><a href="cet9.php?pp='.$arr["slno"].'">'.$arr["Subject_2"].'</a></td>
					  <td bgcolor="#f1f1f1"><strong><font color="red">'.$arr["Posted_by"].'</font></strong></td>
<td bgcolor="#f1f1f1">
<input type="hidden" name="slno" value="'.$arr["slno"].'" />
			     <input type="submit" name="appr" value="Approve" onclick="return confirm(\'Are you sure,you want to approve this post?\')"/></td>
		    </tr> ';
      
			echo '</form>';
		 }

  print ' </table></body></html>';
	


}

?>
