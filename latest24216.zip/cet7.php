<!Doctype HTML>
<html>
<head>
<title>
Notice
</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="robots" content="noindex,follow">
        <meta name="Description" content="Notice">
<link rel="stylesheet" type="text/css" href="../bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="../bootstrap.css">
<link rel="stylesheet" type="text/css" href="../test2.css">
<link rel="shortcut icon" type="image/x-icon" href="../login-logo.jpg" />
</head>
<body>
<div class="container">


           <div class="headline">
          <div align="center"><strong><font color="#272621">CET NOTICE BOARD<font></strong></div>
        </div></div>
        <div class="Notice">
          <table width="100%" border="1" cellpadding="5" cellspacing="2" bgcolor="#ffffff">
					
            <tr>
              <td bgcolor="#2B4B62"><strong><font color="white">Date</font></strong></td>
              <td bgcolor="#2B4B62"><strong><font color="white">Subject</font></strong></td>
							<td bgcolor="#2B4B62"><strong><font color="white">Posted By</font></strong></td>

            </tr>
<?php
	include 'db.php';
	$q=mysqli_query($p,"select slno,Date_1,Posted_by,Subject_1 from notic order by slno desc");
	


	     while($arr=mysqli_fetch_array($q))
		 {
			 echo '<form action="cet6.php">';

   echo '	<tr>
			  <td bgcolor="#f1f1f1"><strong>'.$arr["Date_1"].'
       </strong></td>
			  <td  bgcolor="#f1f1f1" ><a href="cet5.php?pp='.$arr["slno"].'">'.$arr["Subject_1"].'</a></td>
					  <td bgcolor="#f1f1f1"><strong><font color="red">'.$arr["Posted_by"].'</font></strong></td>
<td bgcolor="#f1f1f1">
<input type="hidden" name="slno" value="'.$arr["slno"].'" />

		    </tr> ';
      
			echo '</form>';
		 }
	?>
   </table></body></html>
	
