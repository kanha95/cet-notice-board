<?php


if($_SERVER['REQUEST_METHOD']!='POST'){
print '
<!Doctype HTML>
<html>
<head>
<title>
Notice
</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="robots" content="noindex,follow">
        <meta name="Description" content="Notice">
<link rel="stylesheet" type="text/css" href="../bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="../bootstrap.css">
<link rel="stylesheet" type="text/css" href="../test2.css">
<link rel="shortcut icon" type="image/x-icon" href="../login-logo.jpg" />
</head>
<body>

<div class="container">
<div class="row-center" >
  <div class="col-md-6 col-xs-6 col-md-offset-4">
  <form  id="input" enctype="multipart/form-data" method="post">
  <br><p>Your Name:</p>
   <input type="text"  name="name" size="28" maxlength="15" />


 <p>Subject:</p>
  <textarea wrap="soft"   name="sub" rows="2" cols="30" maxlength="20"></textarea>

  </br><p>Message:</p>
  <textarea wrap="soft"  name="message"  rows="9" cols="30" maxlength="1000"></textarea>

  <p>Attachments:</p>
 <input type="hidden" name="MAX_FILE_SIZE" value="30000" />
  <input type="file" name="f" />
<input type="file" name="ft" />
 </br>

  <input type="submit" name="submit" class="btn btn-primary" value="&nbsp;&nbsp;Post&nbsp;&nbsp;"/>

  </form>

</div>
</div>

</div>

</body>
</html>';
}

 if(isset($_REQUEST["submit"]) AND $_SERVER['REQUEST_METHOD']=="POST")
	{
		$fname=$_FILES["f"]["name"];
	    $file=$_FILES["f"]["tmp_name"];
	    move_uploaded_file($file,$fname);
		$fname1=$_FILES["ft"]["name"];
	    $file1=$_FILES["ft"]["tmp_name"];
	    move_uploaded_file($file1,$fname1);
		$p=mysqli_connect("mysql.hostinger.in","u684872378_cetb","123456","u684872378_cet");
		if(!$p)
	    {
		die("not connected "."<br>".mysql_error());		
	    }	
		
		
		
		
		if(mysqli_query($p,"insert into n_user values(0,current_timestamp,'".$_REQUEST["name"]."','".$_REQUEST["sub"].        "','".$_REQUEST[        "message"]."','".$fname.','.$fname1."')")){
//

print'<!Doctype HTML>
<html>
<head>
<title>
Notice
</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="robots" content="noindex,follow">
        <meta name="Description" content="Notice">
<link rel="stylesheet" type="text/css" href="../bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="../bootstrap.css">
<link rel="stylesheet" type="text/css" href="../test2.css">
<link rel="shortcut icon" type="image/x-icon" href="../login-logo.jpg" />
</head>
<body>
<div class="container">
';
     print"<strong>Thanks For submitting !!!</br>Please Wait For An Admin To Approve Your Post.</strong>";
      print '<p><a href="n_user.php">Post Another Notice</a></p>';
      print '<p><a href="cet7.php">View Notice Board</a></p>';

//
}
			
	}


?>