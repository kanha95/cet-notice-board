<?php
	$u=$_REQUEST["slno"];
	include 'db.php';
         
	if(isset($_REQUEST["appr"]) AND $_SERVER['REQUEST_METHOD']=='POST')
	{
		$q=mysqli_query($p,"select slno,Date_2,Posted_by,Subject_2 from n_user where slno='".$u."' ");
                $arr=mysqli_fetch_array($q);
if(mysqli_query($p,"insert into notic values(0,current_date,'".$arr["Posted_by"]."','".$arr["Subject_2"]."','".$arr["Message"]."','".$arr['Attachment']."')")){
//

print'<!Doctype HTML>
<html>
<head>
<title>
Notice
</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="robots" content="noindex,follow">
        <meta name="Description" content="Notice">
<link rel="stylesheet" type="text/css" href="../bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="../bootstrap.css">
<link rel="stylesheet" type="text/css" href="../test2.css">
<link rel="shortcut icon" type="image/x-icon" href="../login-logo.jpg" />
</head>
<body>
<div class="container">
';
     print"<strong>Thanks For Approving !!!</strong>";
      
      print '<p><a href="cet7.php">View Notice Board</a></p>';

//
} 
        mysqli_query($p,"delete from n_user where slno='".$u."'");

	}

	
?>