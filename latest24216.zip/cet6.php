<?php
	$u=$_REQUEST["slno"];
	include 'db.php';
         
	if(isset($_REQUEST["del"]) AND $_SERVER['request_method']=='POST')
	{
		mysqli_query($p,"delete from notic where slno='".$u."'");
	    header ("location:cet7.php");
	}

	
?>


